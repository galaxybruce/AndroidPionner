/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.galaxybruce.testlibrary;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.galaxybruce.testlibrary";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String APP_PLATFORM_FLAG = "app2";
}
